VeriWorkly Brand Kit
====================

Generated from the live design system. Do not hand-edit - run
"npm run build:brand-kit" from apps/site instead, so this file and the published
pages can never disagree.

Interactive versions, including live component examples and copyable values:

  https://veriworkly.com/brand-kit
  https://veriworkly.com/style-guide


Logo
----
logo/veriworkly-logo-256.png          256×256 PNG   Primary logo mark. For websites, headers, and media placements.
logo/veriworkly-icon-512.png          512×512 PNG   Store listings, app launchers, and high-DPI displays.
logo/veriworkly-icon-192.png          192×192 PNG   Android home screen, manifest, and favicons.
logo/veriworkly-icon-apple-touch.png  180×180 PNG   iOS home screen and web clip.

Official high-resolution PNG image assets for all digital surfaces and media embeds.


Usage
-----
- Clear space on every side equals 25% of the mark's width.
- The mark maintains clarity across all standard digital resolutions.
- Do not recolour, distort, rotate, or add effects (shadows, gradients, outlines).
- Do not place the mark on a ground that breaks its contrast.
- Write "VeriWorkly" as one word, capital V and W.
  Not "Veriworkly", "veriworkly", "Veri Workly", "VeriWorkly.ai".


Colour
------
Every token carries two values. Use the light column on pale grounds and the dark
column on near-black. Alpha values are given as rgba() because they are meant to
composite over whatever is behind them.

Token                   Variable                  Light                    Dark
-------------------------------------------------------------------------------
Background              --background              #F5F4EF                  #0D1117
Foreground              --foreground              #171717                  #F3F4F6
Accent                  --accent                  #2563EB                  #60A5FA
Accent Foreground       --accent-foreground       #F8FBFF                  #0F172A
Card                    --card                    #FFFFFF                  #121924
Muted                   --muted                   #5F5C54                  #94A3B8
Border                  --border                  rgba(23, 23, 23, 0.12)   rgba(148, 163, 184, 0.25)
Destructive             --destructive             #DC2626                  #EF4444
Success                 --success                 #047857                  #34D399
Warning                 --warning                 #B45309                  #FBBF24
Muted Foreground        --muted-foreground        #171717                  #171717
Destructive Foreground  --destructive-foreground  #FFFFFF                  #FFFFFF
Success Foreground      --success-foreground      #FFFFFF                  #052E1F
Warning Foreground      --warning-foreground      #FFFFFF                  #271A02
Docs Highlight          --fd-accent               rgba(96, 165, 250, 0.2)  rgba(130, 139, 2, 0.8)

Machine-readable: palette.json


Typography
----------
Geist Sans (var(--font-geist-sans)) - Interface and body copy.
Geist Mono (var(--font-geist-mono)) - Labels, metadata, code, and numeric detail.

Both are released by Vercel under the SIL Open Font License 1.1 and are available
from Google Fonts. Nothing needs to be licensed to typeset the VeriWorkly name.

Display       36 → 48 → 60 px   weight 600   tracking −0.025em
              Page-opening headline. One per page.

Section       30 px             weight 600   tracking −0.025em
              Section headings.

Component     20 px             weight 600   tracking −0.025em
              Card and panel titles.

Body Large    16 → 18 px        weight 400   tracking 0
              Lead paragraphs and marketing copy.

Body          14 px             weight 400   tracking 0
              Descriptions, list items, and dense UI text.

Eyebrow       12 px             weight 600   tracking 0.24em
              Labels above a heading. Always uppercase.

Mono Meta     12 px             weight 400   tracking 0
              Token names, file paths, dimensions, and code.


Press
-----
Created by     Gautam Raj
Website        veriworkly.com
Licence        MIT - Free-to-use and open-core
Repository     https://github.com/VeriWorkly/veriworkly
X              @veriworkly
LinkedIn       /company/veriworkly
GitHub         /VeriWorkly

Questions about press or brand usage: info@veriworkly.com
